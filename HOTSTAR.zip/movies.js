$(document).ready(function() {
    $('#autoWidth,#autoWidth2').lightSlider({
        autoWidth2:true,
        loop:true,
        onSliderLoad: function() {
            $('#autoWidth,#autoWidth2').removeClass('cS-hidden');
        } 
    });  
  });